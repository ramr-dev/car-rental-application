import { createFileRoute } from "@tanstack/react-router";
import { Camera, Check, FileText, Upload, ShieldAlert, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/store/auth";
import { userService } from "@/lib/api";

export const Route = createFileRoute("/dashboard/kyc")({ component: KycPage });

const DOCS = [
  { id: "license", title: "Driving License", desc: "Front and back of your valid license", icon: FileText },
  { id: "passport", title: "Passport / National ID", desc: "Government-issued photo ID", icon: FileText },
  { id: "selfie", title: "Selfie Verification", desc: "A clear photo of your face", icon: Camera },
] as const;

function KycPage() {
  const { user, setUser } = useAuth();
  const [uploaded, setUploaded] = useState<Record<string, boolean>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const kycStatus = user?.kycStatus ?? "not_started";
  const allUploaded = DOCS.every((doc) => uploaded[doc.id]);

  const handleUpload = (id: string, name: string) => {
    setUploaded((u) => ({ ...u, [id]: true }));
    toast.success(`${name} uploaded successfully!`);
  };

  const handleSubmit = async () => {
    if (!user) return;
    setIsSubmitting(true);
    try {
      const updatedUser = await userService.updateKyc(user.email, "pending");
      setUser(updatedUser);
      toast.success("Identity documents submitted for review! We will verify them shortly.");
    } catch (err) {
      toast.error("Failed to submit documents. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Helper for dynamic timeline dates and statuses
  const getTimelineSteps = () => {
    switch (kycStatus) {
      case "approved":
        return [
          { label: "Documents uploaded", status: "done", date: "Completed" },
          { label: "Compliance review", status: "done", date: "Approved" },
          { label: "Account unlocked", status: "done", date: "Verified" },
        ];
      case "rejected":
        return [
          { label: "Documents uploaded", status: "done", date: "Completed" },
          { label: "Compliance review", status: "rejected", date: "Rejected" },
          { label: "Documents invalid", status: "pending", date: "Re-upload required" },
        ];
      case "pending":
        return [
          { label: "Documents uploaded", status: "done", date: "Just now" },
          { label: "Compliance review", status: "current", date: "Under verification" },
          { label: "Account unlocked", status: "pending", date: "Expected within 24h" },
        ];
      case "not_started":
      default:
        return [
          { label: "Documents uploaded", status: "pending", date: "Awaiting files" },
          { label: "Compliance review", status: "pending", date: "—" },
          { label: "Account unlocked", status: "pending", date: "—" },
        ];
    }
  };

  const badgeConfig = {
    not_started: { label: "Not Started", className: "bg-muted text-muted-foreground" },
    pending: { label: "In Review", className: "bg-warning text-warning-foreground animate-pulse" },
    approved: { label: "Verified Profile", className: "bg-success text-success-foreground shadow-glow" },
    rejected: { label: "Rejected", className: "bg-destructive text-destructive-foreground" },
  };

  const badge = badgeConfig[kycStatus];
  const steps = getTimelineSteps();

  return (
    <div className="mx-auto max-w-5xl">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">KYC Verification</h1>
          <p className="mt-1 text-muted-foreground">Complete identity verification to unlock premium luxury rentals.</p>
        </div>
        <Badge className={`gap-1.5 px-3 py-1 font-semibold text-xs rounded-full ${badge.className}`}>
          {kycStatus === "approved" ? <ShieldCheck className="h-3.5 w-3.5" /> : <Upload className="h-3.5 w-3.5" />}
          {badge.label}
        </Badge>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_300px]">
        {/* Main Area */}
        <div className="space-y-4">
          {kycStatus === "approved" ? (
            <Card className="p-8 text-center bg-success/5 border-success/30 flex flex-col items-center justify-center">
              <div className="h-14 w-14 rounded-full bg-success/10 text-success flex items-center justify-center mb-4">
                <ShieldCheck className="h-8 w-8" />
              </div>
              <h3 className="font-display text-xl font-bold">Verification Successful!</h3>
              <p className="text-sm text-muted-foreground mt-2 max-w-md">
                Your credentials have been verified by our compliance team. You now have full access to reserve any vehicle in our luxury fleet.
              </p>
              <Button asChild className="mt-6 shadow-glow">
                <a href="/vehicles">Rent a vehicle now</a>
              </Button>
            </Card>
          ) : kycStatus === "pending" ? (
            <Card className="p-8 text-center bg-warning/5 border-warning/30 flex flex-col items-center justify-center">
              <div className="h-14 w-14 rounded-full bg-warning/10 text-warning flex items-center justify-center mb-4 animate-pulse">
                <Upload className="h-8 w-8" />
              </div>
              <h3 className="font-display text-xl font-bold">Verification In Progress</h3>
              <p className="text-sm text-muted-foreground mt-2 max-w-md">
                Your documents have been submitted and are currently being audited by compliance. This usually takes less than 24 hours. We'll send an email once verified.
              </p>
            </Card>
          ) : (
            <>
              {kycStatus === "rejected" && (
                <div className="rounded-xl border border-destructive/40 bg-destructive/5 p-4 text-sm flex gap-3 text-destructive-foreground items-start">
                  <ShieldAlert className="h-5 w-5 shrink-0 text-destructive" />
                  <div>
                    <p className="font-semibold text-xs">Submission Rejected</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      Our audit team was unable to verify your previous submission. Please ensure your driver's license and passports are fully legible and not expired.
                    </p>
                  </div>
                </div>
              )}

              {DOCS.map((doc) => {
                const isUp = uploaded[doc.id];
                const Icon = doc.icon;
                return (
                  <Card key={doc.id} className="p-6">
                    <div className="flex flex-wrap items-start justify-between gap-4">
                      <div className="flex gap-4">
                        <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${isUp ? "bg-success/10 text-success" : "bg-accent text-accent-foreground"}`}>
                          {isUp ? <Check className="h-5 w-5" /> : <Icon className="h-5 w-5" />}
                        </div>
                        <div>
                          <p className="font-display font-semibold">{doc.title}</p>
                          <p className="text-sm text-muted-foreground">{doc.desc}</p>
                        </div>
                      </div>
                      <Button
                        variant={isUp ? "outline" : "default"}
                        size="sm"
                        className="cursor-pointer"
                        onClick={() => handleUpload(doc.id, doc.title)}
                      >
                        {isUp ? "Replace" : "Upload"}
                      </Button>
                    </div>

                    {!isUp && (
                      <label className="mt-4 flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-border bg-muted/30 p-8 text-center transition-colors hover:border-primary hover:bg-accent/30">
                        <Upload className="h-6 w-6 text-muted-foreground" />
                        <p className="mt-2 text-sm font-medium">Drop file here or click to browse</p>
                        <p className="text-xs text-muted-foreground">PNG, JPG or PDF — max 10MB</p>
                        <input type="file" className="hidden" onChange={() => handleUpload(doc.id, doc.title)} />
                      </label>
                    )}
                  </Card>
                );
              })}

              <div className="mt-6 flex justify-end">
                <Button 
                  size="lg" 
                  disabled={!allUploaded || isSubmitting} 
                  onClick={handleSubmit}
                  className="shadow-glow w-full sm:w-auto"
                >
                  {isSubmitting ? "Submitting..." : "Submit Verification Audit"}
                </Button>
              </div>
            </>
          )}
        </div>

        {/* Sidebar Status */}
        <Card className="h-fit p-6">
          <h3 className="font-display font-semibold text-lg border-b border-border pb-4">Verification Audit</h3>
          <div className="mt-6 space-y-5">
            {steps.map((s, i) => (
              <div key={i} className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                    s.status === "done" 
                      ? "bg-success text-success-foreground" 
                      : s.status === "current" 
                      ? "bg-primary text-primary-foreground animate-pulse" 
                      : s.status === "rejected"
                      ? "bg-destructive text-destructive-foreground"
                      : "bg-muted text-muted-foreground"
                  }`}>
                    {s.status === "done" ? <Check className="h-3 w-3" /> : i + 1}
                  </div>
                  {i < steps.length - 1 && <div className="mt-1 h-8 w-px bg-border" />}
                </div>
                <div>
                  <p className="text-sm font-medium leading-tight">{s.label}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{s.date}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
