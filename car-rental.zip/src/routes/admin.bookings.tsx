import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Search, MapPin, Calendar, Clock, CheckCircle, Ban, Play, RefreshCw } from "lucide-react";
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { bookingService } from "@/lib/api";
import { toast } from "sonner";
import type { Booking, BookingStatus } from "@/lib/types";

export const Route = createFileRoute("/admin/bookings")({ component: AdminBookings });

function AdminBookings() {
  const queryClient = useQueryClient();
  const { data: bookings = [], isLoading } = useQuery({ queryKey: ["bookings"], queryFn: bookingService.list });
  
  const [q, setQ] = useState("");
  const tabs = ["all", "pending", "confirmed", "active", "completed", "cancelled"] as const;

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }: { id: string; status: BookingStatus }) => 
      bookingService.updateStatus(id, status),
    onSuccess: (updated, variables) => {
      toast.success(`Booking ${updated.id} successfully marked as ${variables.status}`);
      queryClient.invalidateQueries({ queryKey: ["bookings"] });
    },
    onError: () => {
      toast.error("Failed to transition booking status. Please try again.");
    }
  });

  const getStatusBadge = (status: BookingStatus) => {
    switch (status) {
      case "confirmed":
        return "bg-success text-success-foreground shadow-soft border-success/30";
      case "active":
        return "bg-primary text-primary-foreground shadow-glow border-primary/30 animate-pulse";
      case "completed":
        return "bg-secondary text-secondary-foreground border-border";
      case "cancelled":
        return "bg-destructive text-destructive-foreground border-destructive/30";
      case "pending":
      default:
        return "bg-warning text-warning-foreground border-warning/30";
    }
  };

  return (
    <div className="mx-auto max-w-7xl">
      <div>
        <h1 className="font-display text-3xl font-bold tracking-tight">Booking Management</h1>
        <p className="mt-1 text-muted-foreground">Manage and transition customer rental reservations globally.</p>
      </div>

      <Tabs defaultValue="all" className="mt-8">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-border pb-2">
          <TabsList className="h-9">
            {tabs.map((t) => <TabsTrigger key={t} value={t} className="capitalize text-xs px-3">{t}</TabsTrigger>)}
          </TabsList>
          <div className="relative w-full max-w-xs sm:w-auto">
            <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <Input 
              value={q} 
              onChange={(e) => setQ(e.target.value)} 
              placeholder="Search reference or vehicle..." 
              className="pl-8 h-8 text-xs w-full" 
            />
          </div>
        </div>

        {tabs.map((tab) => {
          const filteredByTab = tab === "all" ? bookings : bookings.filter((b) => b.status === tab);
          const filtered = filteredByTab.filter((b) => 
            `${b.id} ${b.vehicleName} ${b.pickupLocation}`.toLowerCase().includes(q.toLowerCase())
          );

          return (
            <TabsContent key={tab} value={tab} className="mt-4">
              <Card className="overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Reference</TableHead>
                      <TableHead>Vehicle Details</TableHead>
                      <TableHead>Dates & Duration</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Total price</TableHead>
                      <TableHead>Operational Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      Array.from({ length: 4 }).map((_, i) => (
                        <TableRow key={i}>
                          <TableCell colSpan={7}>
                            <div className="h-10 animate-pulse rounded bg-muted" />
                          </TableCell>
                        </TableRow>
                      ))
                    ) : filtered.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                          No matching reservations found.
                        </TableCell>
                      </TableRow>
                    ) : (
                      filtered.map((b) => (
                        <TableRow key={b.id}>
                          <TableCell className="font-mono text-xs font-semibold">{b.id}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <img src={b.vehicleImage} alt="" className="h-10 w-14 rounded object-cover border border-border" />
                              <p className="font-semibold text-sm">{b.vehicleName}</p>
                            </div>
                          </TableCell>
                          <TableCell className="text-xs space-y-0.5">
                            <p className="font-medium text-muted-foreground">{b.startDate} → {b.endDate}</p>
                            <p className="text-[10px] text-muted-foreground">Ocular check OK</p>
                          </TableCell>
                          <TableCell className="text-xs text-muted-foreground">{b.pickupLocation}</TableCell>
                          <TableCell className="font-semibold text-sm">${b.totalPrice}</TableCell>
                          <TableCell>
                            <Badge className={`capitalize rounded-full text-[10px] border px-2 py-0.5 ${getStatusBadge(b.status)}`}>
                              {b.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-1.5">
                              {b.status === "pending" && (
                                <>
                                  <Button 
                                    size="sm" 
                                    variant="outline" 
                                    className="hover:bg-destructive/10 text-destructive border-destructive/20 h-8 cursor-pointer"
                                    onClick={() => updateStatusMutation.mutate({ id: b.id, status: "cancelled" })}
                                    disabled={updateStatusMutation.isPending}
                                    title="Cancel reservation"
                                  >
                                    <Ban className="h-3.5 w-3.5" />
                                  </Button>
                                  <Button 
                                    size="sm" 
                                    className="bg-success hover:bg-success/90 text-success-foreground h-8 cursor-pointer shadow-soft"
                                    onClick={() => updateStatusMutation.mutate({ id: b.id, status: "confirmed" })}
                                    disabled={updateStatusMutation.isPending}
                                    title="Approve & Confirm reservation"
                                  >
                                    <CheckCircle className="h-3.5 w-3.5 mr-1" /> Confirm
                                  </Button>
                                </>
                              )}
                              
                              {b.status === "confirmed" && (
                                <Button 
                                  size="sm" 
                                  className="bg-primary hover:bg-primary/90 text-primary-foreground h-8 cursor-pointer shadow-soft"
                                  onClick={() => updateStatusMutation.mutate({ id: b.id, status: "active" })}
                                  disabled={updateStatusMutation.isPending}
                                  title="Dispatch vehicle keys (Customer pickup)"
                                >
                                  <Play className="h-3.5 w-3.5 mr-1 fill-current" /> Dispatch
                                </Button>
                              )}

                              {b.status === "active" && (
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  className="hover:bg-success/10 text-success border-success/20 h-8 cursor-pointer"
                                  onClick={() => updateStatusMutation.mutate({ id: b.id, status: "completed" })}
                                  disabled={updateStatusMutation.isPending}
                                  title="Receive vehicle return (Mark complete)"
                                >
                                  <RefreshCw className="h-3.5 w-3.5 mr-1 animate-spin" style={{ animationDuration: "3s" }} /> Receive Return
                                </Button>
                              )}

                              {b.status === "completed" && (
                                <span className="text-xs text-muted-foreground font-medium px-2 py-1">Archived</span>
                              )}
                              {b.status === "cancelled" && (
                                <span className="text-xs text-destructive font-medium px-2 py-1">Cancelled</span>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </Card>
            </TabsContent>
          );
        })}
      </Tabs>
    </div>
  );
}
