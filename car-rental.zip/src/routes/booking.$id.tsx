import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Check, CreditCard, MapPin, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { PublicLayout } from "@/layouts/PublicLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { vehicleService, bookingService } from "@/lib/api";
import { useBookingDraft } from "@/store/booking";
import { BOOKING_STEPS, BOOKING_ADDONS, SECURITY_DEPOSIT } from "@/constants";
import { calcBookingTotal } from "@/utils/formatters";
import type { Booking } from "@/lib/types";

export const Route = createFileRoute("/booking/$id")({
  component: BookingPage,
});

const paymentSchema = z.object({
  name: z.string().min(2, "Cardholder name required"),
  card: z
    .string()
    .regex(/^\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}$/, "Enter a valid 16-digit card number"),
  expiry: z
    .string()
    .regex(/^(0[1-9]|1[0-2])\/\d{2}$/, "Use MM/YY format"),
  cvc: z.string().regex(/^\d{3,4}$/, "CVC must be 3–4 digits"),
  pickup: z.string().optional(),
  dropoff: z.string().optional(),
});

type PaymentForm = z.infer<typeof paymentSchema>;

const PAYMENT_FORM_ID = "payment-form";

function BookingPage() {
  const { id } = Route.useParams();
  const { draft, setDraft, reset } = useBookingDraft();
  const queryClient = useQueryClient();
  const { data: vehicle } = useQuery({
    queryKey: ["vehicle", id],
    queryFn: () => vehicleService.get(id),
  });
  const [step, setStep] = useState(0);
  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<PaymentForm>({
    resolver: zodResolver(paymentSchema),
    defaultValues: { pickup: "", dropoff: "", card: "", expiry: "", cvc: "", name: "" },
  });

  const createBookingMutation = useMutation({
    mutationFn: (formData: PaymentForm) => {
      if (!vehicle) throw new Error("Vehicle not found");
      return bookingService.create({
        vehicleId: vehicle.id,
        vehicleName: vehicle.name,
        vehicleImage: vehicle.image,
        startDate: draft.startDate ?? new Date().toISOString().slice(0, 10),
        endDate: draft.endDate ?? new Date().toISOString().slice(0, 10),
        pickupLocation: formData.pickup || draft.pickupLocation || "—",
        dropoffLocation: formData.dropoff || draft.dropoffLocation || "Same as pickup",
        totalPrice: total,
      });
    },
    onSuccess: (booking) => {
      queryClient.invalidateQueries({ queryKey: ["bookings"] });
      reset();
      setConfirmedBooking(booking);
      toast.success("Booking confirmed! Check your dashboard for details.");
    },
    onError: () => {
      toast.error("Something went wrong. Please try again.");
    },
  });

  if (!vehicle) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }

  const days =
    draft.startDate && draft.endDate
      ? Math.max(
          1,
          Math.ceil(
            (new Date(draft.endDate).getTime() - new Date(draft.startDate).getTime()) /
              86_400_000,
          ),
        )
      : 3;

  const addonsTotal = draft.addons.reduce(
    (sum, addonId) =>
      sum + (BOOKING_ADDONS.find((a) => a.id === addonId)?.price ?? 0) * days,
    0,
  );

  const { subtotal, fees, total } = calcBookingTotal(
    vehicle.pricePerDay,
    days,
    addonsTotal,
  );

  if (confirmedBooking) {
    return (
      <PublicLayout>
        <div className="container mx-auto max-w-2xl px-4 py-20 text-center lg:px-8">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-success/10 text-success shadow-glow">
            <Check className="h-8 w-8" />
          </div>
          <h1 className="mt-6 font-display text-3xl font-bold">Booking confirmed!</h1>
          <p className="mt-2 text-muted-foreground">
            Your reservation for {vehicle.name} is locked in. We've sent a confirmation
            to your email.
          </p>
          <Card className="mt-8 p-6 text-left">
            <div className="flex items-center gap-4">
              <img
                src={vehicle.image}
                alt=""
                className="h-20 w-28 rounded-lg object-cover"
              />
              <div>
                <p className="font-display font-semibold">{vehicle.name}</p>
                <p className="text-sm text-muted-foreground">
                  {days} day{days > 1 ? "s" : ""} • Total ${confirmedBooking.totalPrice}
                </p>
                <p className="mt-1 text-xs font-mono text-muted-foreground">
                  Booking #{confirmedBooking.id}
                </p>
              </div>
            </div>
          </Card>
          <div className="mt-8 flex justify-center gap-3">
            <Button asChild>
              <Link to="/dashboard/bookings">View Bookings</Link>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/vehicles">Browse more</Link>
            </Button>
          </div>
        </div>
      </PublicLayout>
    );
  }

  const next = () => setStep((s) => Math.min(BOOKING_STEPS.length - 1, s + 1));
  const prev = () => setStep((s) => Math.max(0, s - 1));
  const isLastStep = step === BOOKING_STEPS.length - 1;

  return (
    <PublicLayout>
      <div className="container mx-auto px-4 py-10 lg:px-8">
        {/* ── Stepper ───────────────────────────────────── */}
        <nav className="mb-10" aria-label="Booking steps">
          <div className="flex items-center justify-between gap-2">
            {BOOKING_STEPS.map((label, i) => (
              <div key={label} className="flex flex-1 items-center gap-3">
                <div
                  className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-semibold transition-all ${
                    i <= step
                      ? "bg-primary text-primary-foreground shadow-soft"
                      : "bg-muted text-muted-foreground"
                  }`}
                  aria-current={i === step ? "step" : undefined}
                >
                  {i < step ? <Check className="h-4 w-4" /> : i + 1}
                </div>
                <span
                  className={`hidden text-sm font-medium md:inline ${
                    i === step ? "text-foreground" : "text-muted-foreground"
                  }`}
                >
                  {label}
                </span>
                {i < BOOKING_STEPS.length - 1 && (
                  <div className={`h-px flex-1 ${i < step ? "bg-primary" : "bg-border"}`} />
                )}
              </div>
            ))}
          </div>
        </nav>

        <div className="grid gap-8 lg:grid-cols-[1fr_380px]">
          {/* ── Step content ──────────────────────────── */}
          <Card className="p-6 lg:p-8">
            {step === 0 && (
              <div className="space-y-6">
                <h2 className="font-display text-2xl font-semibold">Trip details</h2>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <Label>Pickup date</Label>
                    <Input
                      type="date"
                      defaultValue={draft.startDate?.slice(0, 10)}
                      onChange={(e) => setDraft({ startDate: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>Drop-off date</Label>
                    <Input
                      type="date"
                      defaultValue={draft.endDate?.slice(0, 10)}
                      onChange={(e) => setDraft({ endDate: e.target.value })}
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <Label>Pickup location</Label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        className="pl-9"
                        placeholder="e.g. SFO Airport"
                        {...register("pickup")}
                        onChange={(e) => setDraft({ pickupLocation: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="sm:col-span-2">
                    <Label>Drop-off location</Label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        className="pl-9"
                        placeholder="Same as pickup"
                        {...register("dropoff")}
                        onChange={(e) => setDraft({ dropoffLocation: e.target.value })}
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {step === 1 && (
              <div className="space-y-6">
                <h2 className="font-display text-2xl font-semibold">Enhance your trip</h2>
                <div className="space-y-3">
                  {BOOKING_ADDONS.map((addon) => {
                    const checked = draft.addons.includes(addon.id);
                    return (
                      <label
                        key={addon.id}
                        className={`flex cursor-pointer items-start gap-4 rounded-xl border p-4 transition-all ${
                          checked
                            ? "border-primary bg-accent/30"
                            : "border-border hover:border-primary/40"
                        }`}
                      >
                        <Checkbox
                          checked={checked}
                          onCheckedChange={(v) =>
                            setDraft({
                              addons: v
                                ? [...draft.addons, addon.id]
                                : draft.addons.filter((x) => x !== addon.id),
                            })
                          }
                          className="mt-1"
                        />
                        <div className="flex-1">
                          <p className="font-medium">{addon.label}</p>
                          <p className="text-sm text-muted-foreground">{addon.desc}</p>
                        </div>
                        <span className="font-semibold">
                          ${addon.price}
                          <span className="text-xs text-muted-foreground">/day</span>
                        </span>
                      </label>
                    );
                  })}
                </div>
              </div>
            )}

            {step === 2 && (
              <form
                id={PAYMENT_FORM_ID}
                onSubmit={handleSubmit(next)}
                className="space-y-6"
              >
                <h2 className="font-display text-2xl font-semibold">Payment</h2>
                <RadioGroup defaultValue="card" className="grid gap-3 sm:grid-cols-3">
                  {(
                    [
                      ["card", "Credit Card"],
                      ["paypal", "PayPal"],
                      ["apple", "Apple Pay"],
                    ] as const
                  ).map(([v, l]) => (
                    <label
                      key={v}
                      className="flex cursor-pointer items-center gap-2 rounded-lg border border-border p-3 hover:border-primary"
                    >
                      <RadioGroupItem value={v} />
                      <span className="text-sm font-medium">{l}</span>
                    </label>
                  ))}
                </RadioGroup>
                <div className="space-y-4">
                  <div>
                    <Label>Cardholder name</Label>
                    <Input placeholder="John Doe" {...register("name")} />
                    {errors.name && (
                      <p className="mt-1 text-xs text-destructive">{errors.name.message}</p>
                    )}
                  </div>
                  <div>
                    <Label>Card number</Label>
                    <div className="relative">
                      <CreditCard className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        className="pl-9"
                        placeholder="1234 5678 9012 3456"
                        {...register("card")}
                      />
                    </div>
                    {errors.card && (
                      <p className="mt-1 text-xs text-destructive">{errors.card.message}</p>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Expiry</Label>
                      <Input placeholder="MM/YY" {...register("expiry")} />
                      {errors.expiry && (
                        <p className="mt-1 text-xs text-destructive">{errors.expiry.message}</p>
                      )}
                    </div>
                    <div>
                      <Label>CVC</Label>
                      <Input placeholder="123" {...register("cvc")} />
                      {errors.cvc && (
                        <p className="mt-1 text-xs text-destructive">{errors.cvc.message}</p>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-3 rounded-xl bg-muted/50 p-4 text-sm">
                  <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-success" />
                  <p className="text-muted-foreground">
                    A ${SECURITY_DEPOSIT} refundable security deposit will be held on your
                    card at pickup and released after vehicle return.
                  </p>
                </div>
              </form>
            )}

            {step === 3 && (
              <div className="space-y-6">
                <h2 className="font-display text-2xl font-semibold">Review & confirm</h2>
                <div className="space-y-4 text-sm">
                  <Row label="Vehicle" value={vehicle.name} />
                  <Row label="Pickup" value={draft.pickupLocation || "—"} />
                  <Row
                    label="Drop-off"
                    value={draft.dropoffLocation || "Same as pickup"}
                  />
                  <Row label="Duration" value={`${days} day${days > 1 ? "s" : ""}`} />
                  <Row
                    label="Add-ons"
                    value={draft.addons.length ? draft.addons.join(", ") : "None"}
                  />
                  <Row label="Total" value={`$${total}`} />
                </div>
              </div>
            )}

            <div className="mt-8 flex justify-between gap-3">
              <Button variant="ghost" onClick={prev} disabled={step === 0}>
                Back
              </Button>
              {step === 2 ? (
                <Button type="submit" form={PAYMENT_FORM_ID}>
                  Continue
                </Button>
              ) : !isLastStep ? (
                <Button onClick={next}>Continue</Button>
              ) : (
                <Button
                  onClick={() => handleSubmit((data) => createBookingMutation.mutate(data))()}
                  disabled={createBookingMutation.isPending}
                  className="shadow-glow"
                >
                  {createBookingMutation.isPending ? "Processing…" : `Confirm & Pay $${total}`}
                </Button>
              )}
            </div>
          </Card>

          {/* ── Order summary ─────────────────────────── */}
          <Card className="h-fit overflow-hidden lg:sticky lg:top-24">
            <img
              src={vehicle.image}
              alt={vehicle.name}
              className="aspect-video w-full object-cover"
            />
            <div className="p-6">
              <h3 className="font-display text-lg font-semibold">{vehicle.name}</h3>
              <p className="text-sm text-muted-foreground">
                {vehicle.brand} • {vehicle.year}
              </p>
              <Separator className="my-4" />
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">
                    ${vehicle.pricePerDay} × {days} day{days > 1 ? "s" : ""}
                  </span>
                  <span>${subtotal}</span>
                </div>
                {addonsTotal > 0 && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Add-ons</span>
                    <span>${addonsTotal}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Service fees</span>
                  <span>${fees}</span>
                </div>
                <Separator />
                <div className="flex justify-between font-display text-base font-bold">
                  <span>Total</span>
                  <span>${total}</span>
                </div>
                <p className="pt-2 text-xs text-muted-foreground">
                  + ${SECURITY_DEPOSIT} refundable deposit
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </PublicLayout>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between border-b border-border pb-3">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}
