import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Grid3x3, List, Search, SlidersHorizontal } from "lucide-react";
import { useState } from "react";
import { PublicLayout } from "@/layouts/PublicLayout";
import { FilterGroup } from "@/components/vehicles/FilterGroup";
import { VehicleCard, VehicleCardSkeleton } from "@/components/vehicles/VehicleCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { EmptyState } from "@/components/common/EmptyState";
import { vehicleService } from "@/lib/api";
import {
  VEHICLE_TYPES,
  FUEL_TYPES,
  TRANSMISSIONS,
  SEAT_OPTIONS,
  SORT_OPTIONS,
  PRICE_RANGE_MIN,
  PRICE_RANGE_MAX,
  PRICE_RANGE_STEP,
} from "@/constants";
import { useVehicleFilters } from "@/hooks/useVehicleFilters";
import type { SortOption } from "@/hooks/useVehicleFilters";

export const Route = createFileRoute("/vehicles")({
  head: () => ({
    meta: [
      { title: "Browse Vehicles — DriveLux" },
      { name: "description", content: "Browse our full fleet of premium rental vehicles." },
    ],
  }),
  component: VehiclesPage,
});

function VehiclesPage() {
  const { data, isLoading } = useQuery({ queryKey: ["vehicles"], queryFn: vehicleService.list });
  const [view, setView] = useState<"grid" | "list">("grid");
  const {
    filters,
    set,
    toggleType,
    toggleFuel,
    toggleTransmission,
    reset,
    filtered,
    paginated,
    page,
    pageCount,
    setPage,
  } = useVehicleFilters(data);

  const filterPanel = (
    <div className="space-y-6">
      <div>
        <Label className="text-xs font-semibold uppercase tracking-wider">Price per day</Label>
        <div className="mt-4">
          <Slider
            value={filters.price}
            onValueChange={(v) => set("price", v as [number, number])}
            min={PRICE_RANGE_MIN}
            max={PRICE_RANGE_MAX}
            step={PRICE_RANGE_STEP}
          />
          <div className="mt-2 flex justify-between text-sm text-muted-foreground">
            <span>${filters.price[0]}</span>
            <span>${filters.price[1]}</span>
          </div>
        </div>
      </div>

      <FilterGroup
        label="Vehicle Type"
        options={VEHICLE_TYPES}
        selected={filters.types}
        onToggle={toggleType}
      />
      <FilterGroup
        label="Fuel"
        options={FUEL_TYPES}
        selected={filters.fuels}
        onToggle={toggleFuel}
      />
      <FilterGroup
        label="Transmission"
        options={TRANSMISSIONS}
        selected={filters.transmissions}
        onToggle={toggleTransmission}
      />

      <div>
        <Label className="text-xs font-semibold uppercase tracking-wider">Min Seats</Label>
        <div className="mt-3 flex flex-wrap gap-2">
          {SEAT_OPTIONS.map((n) => (
            <Button
              key={n}
              size="sm"
              variant={filters.minSeats === n ? "default" : "outline"}
              onClick={() => set("minSeats", filters.minSeats === n ? null : n)}
            >
              {n}+
            </Button>
          ))}
        </div>
      </div>

      <Button variant="ghost" className="w-full" onClick={reset}>
        Reset filters
      </Button>
    </div>
  );

  return (
    <PublicLayout>
      <div className="container mx-auto px-4 py-10 lg:px-8">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold tracking-tight">Browse our fleet</h1>
          <p className="mt-1 text-muted-foreground">{filtered.length} vehicles available</p>
        </div>

        <div className="grid gap-8 lg:grid-cols-[280px_1fr]">
          {/* Desktop sidebar */}
          <Card className="hidden h-fit p-6 lg:block">{filterPanel}</Card>

          <div>
            {/* Toolbar */}
            <div className="flex flex-wrap items-center gap-3">
              <div className="relative min-w-0 flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={filters.search}
                  onChange={(e) => set("search", e.target.value)}
                  placeholder="Search by name or brand…"
                  className="pl-10"
                  aria-label="Search vehicles"
                />
              </div>

              {/* Mobile filter sheet */}
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" className="lg:hidden">
                    <SlidersHorizontal className="mr-2 h-4 w-4" />
                    Filters
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-80 overflow-y-auto">
                  <SheetHeader>
                    <SheetTitle>Filters</SheetTitle>
                  </SheetHeader>
                  <div className="mt-6">{filterPanel}</div>
                </SheetContent>
              </Sheet>

              <Select
                value={filters.sort}
                onValueChange={(v) => set("sort", v as SortOption)}
              >
                <SelectTrigger className="w-44">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SORT_OPTIONS.map((o) => (
                    <SelectItem key={o.value} value={o.value}>
                      {o.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <div className="flex rounded-lg border border-border p-0.5">
                <Button
                  size="icon"
                  variant={view === "grid" ? "secondary" : "ghost"}
                  className="h-8 w-8"
                  onClick={() => setView("grid")}
                  aria-label="Grid view"
                >
                  <Grid3x3 className="h-4 w-4" />
                </Button>
                <Button
                  size="icon"
                  variant={view === "list" ? "secondary" : "ghost"}
                  className="h-8 w-8"
                  onClick={() => setView("list")}
                  aria-label="List view"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Results */}
            <div className="mt-6">
              {isLoading ? (
                <div
                  className={
                    view === "grid" ? "grid gap-6 sm:grid-cols-2 xl:grid-cols-3" : "space-y-4"
                  }
                >
                  {Array.from({ length: 6 }).map((_, i) => (
                    <VehicleCardSkeleton key={i} />
                  ))}
                </div>
              ) : paginated.length === 0 ? (
                <EmptyState
                  title="No vehicles found"
                  description="Try adjusting your filters or search query."
                />
              ) : (
                <div
                  className={
                    view === "grid" ? "grid gap-6 sm:grid-cols-2 xl:grid-cols-3" : "space-y-4"
                  }
                >
                  {paginated.map((v) => (
                    <VehicleCard key={v.id} vehicle={v} variant={view} />
                  ))}
                </div>
              )}
            </div>

            {/* Pagination */}
            {pageCount > 1 && (
              <nav
                className="mt-10 flex items-center justify-center gap-2"
                aria-label="Pagination"
              >
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page === 1}
                  onClick={() => setPage((p) => p - 1)}
                >
                  Previous
                </Button>
                {Array.from({ length: pageCount }).map((_, i) => (
                  <Button
                    key={i}
                    size="sm"
                    variant={page === i + 1 ? "default" : "outline"}
                    onClick={() => setPage(i + 1)}
                    aria-current={page === i + 1 ? "page" : undefined}
                  >
                    {i + 1}
                  </Button>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page === pageCount}
                  onClick={() => setPage((p) => p + 1)}
                >
                  Next
                </Button>
              </nav>
            )}
          </div>
        </div>
      </div>
    </PublicLayout>
  );
}
