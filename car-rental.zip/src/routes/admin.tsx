import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { Navbar } from "@/components/layout/Navbar";
import { DashboardSidebar } from "@/components/layout/DashboardSidebar";

export const Route = createFileRoute("/admin")({
  beforeLoad: () => {
    if (typeof window !== "undefined") {
      const raw = localStorage.getItem("drivelux-auth");
      const user = raw ? JSON.parse(raw)?.state?.user : null;
      if (!user) throw redirect({ to: "/login" });
      if (user.role !== "admin") throw redirect({ to: "/dashboard" });
    }
  },
  component: AdminLayout,
});

function AdminLayout() {
  return (
    <div className="min-h-screen bg-muted/20">
      <Navbar />
      <div className="flex">
        <DashboardSidebar scope="admin" />
        <main className="flex-1 px-4 py-8 lg:px-8"><Outlet /></main>
      </div>
    </div>
  );
}
