import { createFileRoute } from "@tanstack/react-router";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export const Route = createFileRoute("/admin/payments")({ component: AdminPayments });

const PAYMENTS = [
  { id: "PAY-9281", customer: "Sarah Chen", method: "Visa •• 4242", amount: 945, status: "succeeded", date: "Just now" },
  { id: "PAY-9280", customer: "Marcus Johnson", method: "MC •• 8821", amount: 720, status: "succeeded", date: "1h ago" },
  { id: "PAY-9279", customer: "Elena Rossi", method: "PayPal", amount: 1240, status: "succeeded", date: "3h ago" },
  { id: "PAY-9278", customer: "David Kim", method: "Visa •• 0001", amount: 1850, status: "refunded", date: "1d ago" },
  { id: "PAY-9277", customer: "Maya Patel", method: "Apple Pay", amount: 480, status: "pending", date: "2d ago" },
];

function AdminPayments() {
  return (
    <div className="mx-auto max-w-7xl">
      <h1 className="font-display text-3xl font-bold tracking-tight">Payments</h1>
      <p className="mt-1 text-muted-foreground">All transactions across your platform.</p>

      <Card className="mt-8 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Reference</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Method</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {PAYMENTS.map((p) => (
              <TableRow key={p.id}>
                <TableCell className="font-mono text-xs">{p.id}</TableCell>
                <TableCell className="font-medium">{p.customer}</TableCell>
                <TableCell className="text-sm text-muted-foreground">{p.method}</TableCell>
                <TableCell className="font-medium">${p.amount}</TableCell>
                <TableCell>
                  <Badge variant={p.status === "succeeded" ? "default" : p.status === "refunded" ? "secondary" : "outline"} className={`capitalize ${p.status === "succeeded" ? "bg-success text-success-foreground" : ""}`}>
                    {p.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-sm text-muted-foreground">{p.date}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
