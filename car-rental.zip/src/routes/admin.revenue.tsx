import { createFileRoute } from "@tanstack/react-router";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { Card } from "@/components/ui/card";
import { StatCard } from "@/components/dashboard/StatCard";
import { DollarSign, PiggyBank, ReceiptText, Wallet } from "lucide-react";

export const Route = createFileRoute("/admin/revenue")({ component: AdminRevenue });

const lineData = Array.from({ length: 12 }).map((_, i) => ({
  month: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][i],
  revenue: 30000 + Math.round(Math.sin(i / 2) * 12000 + i * 4500),
  costs: 12000 + Math.round(Math.cos(i / 3) * 4000 + i * 1200),
}));

// Static hex colors for recharts — oklch CSS custom properties are not parsed by SVG renderers.
const PIE_COLORS = ["#6366f1", "#10b981", "#f59e0b", "#ec4899"];

const pieData = [
  { name: "Luxury", value: 38 },
  { name: "SUV", value: 28 },
  { name: "Sedan", value: 18 },
  { name: "Electric", value: 16 },
];

const PRIMARY = "#6366f1";
const DESTRUCTIVE = "#ef4444";

function useCssChartStyles() {
  if (typeof window === "undefined") {
    return {
      gridColor: "#e2e8f0",
      axisColor: "#94a3b8",
      tooltipStyle: {
        background: "#ffffff",
        border: "1px solid #e2e8f0",
        borderRadius: 12,
        fontSize: 13,
      },
    };
  }
  const cs = getComputedStyle(document.documentElement);
  const border = cs.getPropertyValue("--border").trim();
  const mutedFg = cs.getPropertyValue("--muted-foreground").trim();
  const cardBg = cs.getPropertyValue("--card").trim();
  return {
    gridColor: `oklch(${border})`,
    axisColor: `oklch(${mutedFg})`,
    tooltipStyle: {
      background: `oklch(${cardBg})`,
      border: `1px solid oklch(${border})`,
      borderRadius: 12,
      fontSize: 13,
    },
  };
}

function AdminRevenue() {
  const { gridColor, axisColor, tooltipStyle } = useCssChartStyles();

  return (
    <div className="mx-auto max-w-7xl">
      <h1 className="font-display text-3xl font-bold tracking-tight">Revenue Analytics</h1>
      <p className="mt-1 text-muted-foreground">
        Track earnings, costs, and growth across your operations.
      </p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Gross Revenue" value="$684K" delta="+22%" icon={DollarSign} />
        <StatCard label="Net Profit" value="$412K" delta="+18%" icon={PiggyBank} />
        <StatCard label="Avg. Order Value" value="$284" delta="+6%" icon={Wallet} />
        <StatCard label="Refunds" value="$12.4K" delta="-3%" icon={ReceiptText} positive={false} />
      </div>

      <Card className="mt-8 p-6">
        <h3 className="font-display text-lg font-semibold">Revenue vs Costs</h3>
        <div className="mt-6 h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={lineData}>
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
              <XAxis dataKey="month" stroke={axisColor} fontSize={12} />
              <YAxis stroke={axisColor} fontSize={12} />
              <Tooltip contentStyle={tooltipStyle} />
              <Legend />
              <Line
                type="monotone"
                dataKey="revenue"
                stroke={PRIMARY}
                strokeWidth={2.5}
                dot={false}
                name="Revenue"
              />
              <Line
                type="monotone"
                dataKey="costs"
                stroke={DESTRUCTIVE}
                strokeWidth={2.5}
                dot={false}
                name="Costs"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card className="mt-6 p-6">
        <h3 className="font-display text-lg font-semibold">Revenue by category</h3>
        <div className="mt-6 h-72">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={pieData}
                dataKey="value"
                nameKey="name"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={3}
              >
                {pieData.map((_, i) => (
                  <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={tooltipStyle} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}
