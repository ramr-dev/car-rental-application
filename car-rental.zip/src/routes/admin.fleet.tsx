import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, CheckCircle2, Wrench, ShieldAlert, Users, Calendar, ClipboardList, SlidersHorizontal } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { vehicleService } from "@/lib/api";
import type { Vehicle } from "@/lib/types";

export const Route = createFileRoute("/admin/fleet")({ component: AdminFleet });

const STATUS = ["available", "rented", "maintenance", "damage"] as const;
type FleetStatus = (typeof STATUS)[number];

const colors: Record<FleetStatus, string> = {
  available: "bg-success/10 text-success border-success/20",
  rented: "bg-primary/10 text-primary border-primary/20",
  maintenance: "bg-warning/10 text-warning border-warning/20",
  damage: "bg-destructive/10 text-destructive border-destructive/20",
};

type MaintenanceForm = {
  serviceType: string;
  technician: string;
  date: string;
  odometer: number;
  notes: string;
};

type DamageForm = {
  severity: "low" | "medium" | "high";
  estimateCost: number;
  notes: string;
};

type AssignForm = {
  customerName: string;
  pickupDate: string;
  returnDate: string;
};

function AdminFleet() {
  const queryClient = useQueryClient();
  const { data: vehicles = [], isLoading } = useQuery({ queryKey: ["vehicles"], queryFn: vehicleService.list });

  // Dialog states
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const [activeDialog, setActiveDialog] = useState<"status" | "service" | "damage" | "assign" | null>(null);

  // Forms
  const { register: regService, handleSubmit: handleServiceSubmit, reset: resetService } = useForm<MaintenanceForm>();
  const { register: regDamage, handleSubmit: handleDamageSubmit, reset: resetDamage, setValue: setDamageVal } = useForm<DamageForm>({ defaultValues: { severity: "medium" } });
  const { register: regAssign, handleSubmit: handleAssignSubmit, reset: resetAssign } = useForm<AssignForm>();

  const updateMutation = useMutation({
    mutationFn: ({ id, patch }: { id: string; patch: Partial<Vehicle> }) => 
      vehicleService.update(id, patch),
    onSuccess: (updated) => {
      toast.success(`${updated.name} status successfully updated!`);
      queryClient.invalidateQueries({ queryKey: ["vehicles"] });
      closeDialogs();
    },
    onError: () => {
      toast.error("Failed to update vehicle status.");
    }
  });

  const closeDialogs = () => {
    setSelectedVehicle(null);
    setActiveDialog(null);
    resetService();
    resetDamage();
    resetAssign();
  };

  const getVehicleStatus = (v: Vehicle, index: number): FleetStatus => {
    // Determine a dynamic status based on available boolean and index for mock variance
    if (v.available) return "available";
    const subStatuses: FleetStatus[] = ["rented", "maintenance", "damage"];
    return subStatuses[index % subStatuses.length];
  };

  // Recalculate summary stats based on current vehicles list
  const getStats = () => {
    let available = 0;
    let rented = 0;
    let maintenance = 0;
    let damage = 0;

    vehicles.forEach((v, index) => {
      const status = getVehicleStatus(v, index);
      if (status === "available") available++;
      else if (status === "rented") rented++;
      else if (status === "maintenance") maintenance++;
      else if (status === "damage") damage++;
    });

    return { available, rented, maintenance, damage };
  };

  const stats = getStats();

  const handleStatusChange = (status: FleetStatus) => {
    if (!selectedVehicle) return;
    const available = status === "available";
    updateMutation.mutate({ id: selectedVehicle.id, patch: { available } });
  };

  const onServiceSubmit = (data: MaintenanceForm) => {
    if (!selectedVehicle) return;
    toast.success(`Service successfully scheduled for ${selectedVehicle.name}!`);
    // Mutate status to maintenance automatically
    updateMutation.mutate({ id: selectedVehicle.id, patch: { available: false } });
  };

  const onDamageSubmit = (data: DamageForm) => {
    if (!selectedVehicle) return;
    toast.success(`Damage report successfully logged for ${selectedVehicle.name}. Severity: ${data.severity.toUpperCase()}`);
    // Mutate status to damage automatically
    updateMutation.mutate({ id: selectedVehicle.id, patch: { available: false } });
  };

  const onAssignSubmit = (data: AssignForm) => {
    if (!selectedVehicle) return;
    toast.success(`Vehicle successfully assigned to driver: ${data.customerName}!`);
    // Mutate status to rented automatically
    updateMutation.mutate({ id: selectedVehicle.id, patch: { available: false } });
  };

  return (
    <div className="mx-auto max-w-7xl">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">Fleet Management</h1>
          <p className="mt-1 text-muted-foreground">Real-time control, diagnostics and status of every premium asset in operation.</p>
        </div>
      </div>

      {/* Dynamic Summary Cards */}
      <div className="mt-8 grid gap-4 grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Available", value: stats.available, icon: CheckCircle2, className: colors.available },
          { label: "Rented", value: stats.rented, icon: Users, className: colors.rented },
          { label: "Maintenance", value: stats.maintenance, icon: Wrench, className: colors.maintenance },
          { label: "Damage Logged", value: stats.damage, icon: AlertTriangle, className: colors.damage },
        ].map((s) => {
          const Icon = s.icon;
          return (
            <Card key={s.label} className="p-5">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-muted-foreground">{s.label}</p>
                <div className={`flex h-8 w-8 items-center justify-center rounded-lg border ${s.className}`}>
                  <Icon className="h-4.5 w-4.5" />
                </div>
              </div>
              <p className="mt-2 font-display text-3xl font-bold">{isLoading ? "..." : s.value}</p>
            </Card>
          );
        })}
      </div>

      {/* Fleet Dashboard Grid */}
      <div className="mt-8 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {isLoading ? (
          Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="h-80 animate-pulse bg-muted rounded-xl" />
          ))
        ) : vehicles.map((v, i) => {
          const status = getVehicleStatus(v, i);
          return (
            <Card key={v.id} className="overflow-hidden group hover:shadow-soft transition-all duration-300">
              <div className="relative overflow-hidden bg-muted aspect-video">
                <img src={v.image} alt="" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                <Badge className={`absolute right-3 top-3 capitalize border ${colors[status]}`}>
                  {status}
                </Badge>
              </div>
              <div className="p-5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-display font-bold text-lg leading-tight mb-1">{v.name}</h3>
                    <p className="text-xs text-muted-foreground font-mono">ID: #{v.id.toUpperCase()} • {v.location}</p>
                  </div>
                </div>
                <div className="mt-4 space-y-2 text-xs border-b border-border/40 pb-4">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Odometer:</span>
                    <span className="font-medium">{(22450 + i * 2820).toLocaleString()} mi</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Ocular Health check:</span>
                    <span className={`font-semibold ${status === "damage" ? "text-destructive" : "text-success"}`}>
                      {status === "damage" ? "Service Required" : "Excellent"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Diagnostics check:</span>
                    <span>Systems nominal</span>
                  </div>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="cursor-pointer"
                    onClick={() => { setSelectedVehicle(v); setActiveDialog("status"); }}
                  >
                    <SlidersHorizontal className="h-3.5 w-3.5 mr-1" /> Status
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="cursor-pointer"
                    onClick={() => { setSelectedVehicle(v); setActiveDialog("assign"); }}
                  >
                    <Users className="h-3.5 w-3.5 mr-1" /> Assign
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="cursor-pointer"
                    onClick={() => { setSelectedVehicle(v); setActiveDialog("service"); }}
                  >
                    <Wrench className="h-3.5 w-3.5 mr-1" /> Service
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="cursor-pointer hover:bg-destructive/10 text-destructive border-destructive/20"
                    onClick={() => { setSelectedVehicle(v); setActiveDialog("damage"); }}
                  >
                    <AlertTriangle className="h-3.5 w-3.5 mr-1" /> Damage
                  </Button>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Status Editor Dialog */}
      <Dialog open={selectedVehicle !== null && activeDialog === "status"} onOpenChange={(open) => !open && closeDialogs()}>
        {selectedVehicle && (
          <DialogContent className="max-w-md sm:rounded-2xl">
            <DialogHeader>
              <DialogTitle className="font-display text-lg font-bold">Update fleet status</DialogTitle>
              <DialogDescription>Modify availability states for vehicle: {selectedVehicle.name}</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <Label>Select new operational status</Label>
              <Select onValueChange={(val) => handleStatusChange(val as FleetStatus)}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Choose new status..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="available">Available (Active catalog)</SelectItem>
                  <SelectItem value="rented">Rented out (Active trip)</SelectItem>
                  <SelectItem value="maintenance">Maintenance (Offline)</SelectItem>
                  <SelectItem value="damage">Damage Logged (Repair required)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={closeDialogs}>Cancel</Button>
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>

      {/* Maintenance Scheduler Dialog */}
      <Dialog open={selectedVehicle !== null && activeDialog === "service"} onOpenChange={(open) => !open && closeDialogs()}>
        {selectedVehicle && (
          <DialogContent className="max-w-md sm:rounded-2xl">
            <DialogHeader>
              <DialogTitle className="font-display text-lg font-bold flex items-center gap-1.5"><Wrench className="h-5 w-5 text-primary" /> Schedule Maintenance</DialogTitle>
              <DialogDescription>Book a service check or regular maintenance audit for {selectedVehicle.name}.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleServiceSubmit(onServiceSubmit)} className="space-y-4 mt-2">
              <div>
                <Label>Service Type</Label>
                <Input placeholder="Oil change & Engine filter" {...regService("serviceType", { required: true })} />
              </div>
              <div className="grid gap-3 grid-cols-2">
                <div>
                  <Label>Odometer reading (mi)</Label>
                  <Input type="number" placeholder="25000" {...regService("odometer", { required: true })} />
                </div>
                <div>
                  <Label>Service Date</Label>
                  <Input type="date" {...regService("date", { required: true })} />
                </div>
              </div>
              <div>
                <Label>Assigned Technician</Label>
                <Input placeholder="DriveLux Garage Dept" {...regService("technician", { required: true })} />
              </div>
              <div>
                <Label>Service Notes</Label>
                <textarea className="w-full border border-input bg-background rounded-lg p-2.5 text-xs h-16 focus:ring-1 focus:ring-primary outline-none mt-1" placeholder="Add specific checks..." {...regService("notes")} />
              </div>
              <DialogFooter className="mt-4">
                <Button type="button" variant="ghost" onClick={closeDialogs}>Cancel</Button>
                <Button type="submit" className="shadow-soft">Schedule service</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        )}
      </Dialog>

      {/* Damage Logger Dialog */}
      <Dialog open={selectedVehicle !== null && activeDialog === "damage"} onOpenChange={(open) => !open && closeDialogs()}>
        {selectedVehicle && (
          <DialogContent className="max-w-md sm:rounded-2xl">
            <DialogHeader>
              <DialogTitle className="font-display text-lg font-bold flex items-center gap-1.5"><ShieldAlert className="h-5 w-5 text-destructive" /> Log Damage Report</DialogTitle>
              <DialogDescription>Log physical damages or mechanical errors reported on {selectedVehicle.name}.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleDamageSubmit(onDamageSubmit)} className="space-y-4 mt-2">
              <div className="grid gap-3 grid-cols-2">
                <div>
                  <Label>Damage Severity</Label>
                  <Select defaultValue="medium" onValueChange={(val) => setDamageVal("severity", val as "low" | "medium" | "high")}>
                    <SelectTrigger className="w-full mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low (Cosmetic)</SelectItem>
                      <SelectItem value="medium">Medium (Requires fix)</SelectItem>
                      <SelectItem value="high">High (Undriveable)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Repair Estimate ($)</Label>
                  <Input type="number" placeholder="500" {...regDamage("estimateCost", { required: true })} className="mt-1" />
                </div>
              </div>
              <div>
                <Label>Damage details & Ocular notes</Label>
                <textarea className="w-full border border-input bg-background rounded-lg p-2.5 text-xs h-20 focus:ring-1 focus:ring-primary outline-none mt-1" placeholder="Describe the scratch, dent or system diagnostic failure..." {...regDamage("notes", { required: true })} />
              </div>
              <DialogFooter className="mt-4">
                <Button type="button" variant="ghost" onClick={closeDialogs}>Cancel</Button>
                <Button type="submit" variant="destructive">Log damage report</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        )}
      </Dialog>

      {/* Assign Driver Dialog */}
      <Dialog open={selectedVehicle !== null && activeDialog === "assign"} onOpenChange={(open) => !open && closeDialogs()}>
        {selectedVehicle && (
          <DialogContent className="max-w-md sm:rounded-2xl">
            <DialogHeader>
              <DialogTitle className="font-display text-lg font-bold flex items-center gap-1.5"><ClipboardList className="h-5 w-5 text-primary" /> Assign Driver</DialogTitle>
              <DialogDescription>Record a custom rental assignment for {selectedVehicle.name}.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAssignSubmit(onAssignSubmit)} className="space-y-4 mt-2">
              <div>
                <Label>Driver / Customer Name</Label>
                <Input placeholder="John Doe" {...regAssign("customerName", { required: true })} />
              </div>
              <div className="grid gap-3 grid-cols-2">
                <div>
                  <Label>Pickup Date</Label>
                  <Input type="date" {...regAssign("pickupDate", { required: true })} />
                </div>
                <div>
                  <Label>Expected Return Date</Label>
                  <Input type="date" {...regAssign("returnDate", { required: true })} />
                </div>
              </div>
              <DialogFooter className="mt-4">
                <Button type="button" variant="ghost" onClick={closeDialogs}>Cancel</Button>
                <Button type="submit">Confirm assignment</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        )}
      </Dialog>
    </div>
  );
}
