import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Check, X, ShieldAlert, FileText, Eye, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { userService } from "@/lib/api";
import type { User } from "@/lib/types";

export const Route = createFileRoute("/admin/kyc")({ component: AdminKyc });

function AdminKyc() {
  const queryClient = useQueryClient();
  const { data: users = [], isLoading } = useQuery({ queryKey: ["users"], queryFn: userService.list });
  
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  const kycMutation = useMutation({
    mutationFn: ({ email, status }: { email: string; status: "approved" | "rejected" }) => 
      userService.updateKyc(email, status),
    onSuccess: (updatedUser, variables) => {
      toast.success(`Identity status for ${updatedUser.name} marked as ${variables.status}`);
      queryClient.invalidateQueries({ queryKey: ["users"] });
      setSelectedUser(null);
    },
    onError: () => {
      toast.error("Failed to update verification status. Please try again.");
    }
  });

  const getBadgeColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-success text-success-foreground shadow-glow";
      case "rejected":
        return "bg-destructive text-destructive-foreground";
      case "pending":
        return "bg-warning text-warning-foreground animate-pulse";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="mx-auto max-w-7xl">
      <div>
        <h1 className="font-display text-3xl font-bold tracking-tight">KYC Approvals</h1>
        <p className="mt-1 text-muted-foreground">Review, audit and verify customer identity document submissions.</p>
      </div>

      <Tabs defaultValue="pending" className="mt-8">
        <TabsList>
          <TabsTrigger value="pending">Pending review</TabsTrigger>
          <TabsTrigger value="approved">Approved</TabsTrigger>
          <TabsTrigger value="rejected">Rejected</TabsTrigger>
          <TabsTrigger value="all">All customers</TabsTrigger>
        </TabsList>

        {["pending", "approved", "rejected", "all"].map((tab) => {
          const filtered = tab === "all" 
            ? users.filter(u => u.kycStatus !== "not_started") 
            : users.filter((u) => u.kycStatus === tab);

          return (
            <TabsContent key={tab} value={tab} className="mt-6">
              <Card className="overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Customer</TableHead>
                      <TableHead>Phone</TableHead>
                      <TableHead>Required Documents</TableHead>
                      <TableHead>Verification Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      Array.from({ length: 3 }).map((_, i) => (
                        <TableRow key={i}>
                          <TableCell colSpan={5}>
                            <div className="h-10 animate-pulse rounded bg-muted" />
                          </TableCell>
                        </TableRow>
                      ))
                    ) : filtered.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="py-8 text-center text-muted-foreground">
                          No identity submissions found in this category.
                        </TableCell>
                      </TableRow>
                    ) : (
                      filtered.map((r) => (
                        <TableRow key={r.email}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <Avatar>
                                <AvatarFallback className="bg-primary text-primary-foreground text-xs font-semibold">
                                  {r.name.split(" ").map((n) => n[0]).join("")}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-semibold text-sm">{r.name}</p>
                                <p className="text-xs text-muted-foreground">{r.email}</p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="text-sm font-mono">{r.phone || "—"}</TableCell>
                          <TableCell className="text-sm">3 of 3 uploaded</TableCell>
                          <TableCell>
                            <Badge className={`capitalize rounded-full ${getBadgeColor(r.kycStatus)}`}>
                              {r.kycStatus.replace("_", " ")}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button 
                                size="sm" 
                                variant="outline" 
                                className="cursor-pointer"
                                onClick={() => setSelectedUser(r)}
                              >
                                <Eye className="h-3.5 w-3.5 mr-1" /> Audit
                              </Button>
                              {r.kycStatus === "pending" && (
                                <>
                                  <Button 
                                    size="sm" 
                                    variant="outline" 
                                    className="hover:bg-destructive/10 text-destructive border-destructive/20 cursor-pointer"
                                    onClick={() => kycMutation.mutate({ email: r.email, status: "rejected" })}
                                    disabled={kycMutation.isPending}
                                  >
                                    <X className="h-4 w-4" />
                                  </Button>
                                  <Button 
                                    size="sm" 
                                    className="bg-success hover:bg-success/90 text-success-foreground cursor-pointer shadow-soft"
                                    onClick={() => kycMutation.mutate({ email: r.email, status: "approved" })}
                                    disabled={kycMutation.isPending}
                                  >
                                    <Check className="h-4 w-4" />
                                  </Button>
                                </>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </Card>
            </TabsContent>
          );
        })}
      </Tabs>

      {/* KYC Document Audit Dialog Modal */}
      <Dialog open={selectedUser !== null} onOpenChange={(open) => !open && setSelectedUser(null)}>
        {selectedUser && (
          <DialogContent className="max-w-2xl sm:rounded-2xl">
            <DialogHeader>
              <DialogTitle className="font-display text-xl font-bold flex items-center justify-between pr-6">
                <span>Compliance audit folder</span>
                <Badge className={`capitalize rounded-full ${getBadgeColor(selectedUser.kycStatus)}`}>
                  {selectedUser.kycStatus}
                </Badge>
              </DialogTitle>
              <DialogDescription className="text-xs font-semibold">Auditor view for customer {selectedUser.name}</DialogDescription>
            </DialogHeader>

            <div className="mt-4 space-y-6 max-h-[60vh] overflow-y-auto pr-1">
              <div className="grid gap-4 sm:grid-cols-3">
                <Card className="p-3 bg-muted/20 border-border/50 text-center flex flex-col items-center justify-center">
                  <FileText className="h-8 w-8 text-primary mb-2" />
                  <p className="font-semibold text-xs leading-tight">Driving License</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">Front/Back (Legible)</p>
                  <div className="mt-3 text-[10px] text-success font-semibold bg-success/10 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <ShieldCheck className="h-3 w-3" /> Scanned OK
                  </div>
                </Card>
                <Card className="p-3 bg-muted/20 border-border/50 text-center flex flex-col items-center justify-center">
                  <FileText className="h-8 w-8 text-primary mb-2" />
                  <p className="font-semibold text-xs leading-tight">National Passport</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">Photo Page (Matches)</p>
                  <div className="mt-3 text-[10px] text-success font-semibold bg-success/10 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <ShieldCheck className="h-3 w-3" /> Valid Match
                  </div>
                </Card>
                <Card className="p-3 bg-muted/20 border-border/50 text-center flex flex-col items-center justify-center">
                  <Avatar className="h-9 w-9 mb-2"><AvatarFallback className="bg-primary/10 text-primary text-[10px] font-bold">Face</AvatarFallback></Avatar>
                  <p className="font-semibold text-xs leading-tight">Live Selfie Photo</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">Face Match Ocular Check</p>
                  <div className="mt-3 text-[10px] text-success font-semibold bg-success/10 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <ShieldCheck className="h-3 w-3" /> Biometric OK
                  </div>
                </Card>
              </div>

              {/* Document Previews (Stylized Placeholders) */}
              <div className="rounded-xl border border-border p-4 bg-muted/40 space-y-4">
                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Document Scans Preview</p>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="aspect-video bg-white dark:bg-card border border-border rounded-lg relative overflow-hidden p-3 flex flex-col justify-between">
                    <div className="flex justify-between items-start">
                      <p className="text-[10px] font-bold font-mono tracking-wider">LICENSE CLASS D</p>
                      <Badge variant="outline" className="text-[8px] h-4 py-0">Front</Badge>
                    </div>
                    <div className="flex gap-2.5 items-center">
                      <div className="h-10 w-8 bg-muted rounded shrink-0 flex items-center justify-center text-[8px] font-semibold text-muted-foreground">PHOTO</div>
                      <div className="space-y-1 w-full">
                        <div className="h-2 w-3/4 bg-muted rounded" />
                        <div className="h-2 w-1/2 bg-muted rounded" />
                        <div className="h-1.5 w-1/3 bg-muted rounded" />
                      </div>
                    </div>
                    <p className="text-[6px] font-mono text-muted-foreground text-right">USA DDL #D819280192</p>
                  </div>
                  <div className="aspect-video bg-white dark:bg-card border border-border rounded-lg relative overflow-hidden p-3 flex flex-col justify-between">
                    <div className="flex justify-between items-start">
                      <p className="text-[10px] font-bold font-mono tracking-wider">PASSPORT OFFICE</p>
                      <Badge variant="outline" className="text-[8px] h-4 py-0">Main Page</Badge>
                    </div>
                    <div className="flex gap-2.5 items-center">
                      <div className="h-10 w-8 bg-muted rounded shrink-0 flex items-center justify-center text-[8px] font-semibold text-muted-foreground">PHOTO</div>
                      <div className="space-y-1 w-full">
                        <div className="h-2 w-2/3 bg-muted rounded" />
                        <div className="h-2 w-3/4 bg-muted rounded" />
                        <div className="h-1.5 w-1/2 bg-muted rounded" />
                      </div>
                    </div>
                    <p className="text-[6px] font-mono text-muted-foreground text-right">P-USA #9201928</p>
                  </div>
                </div>
              </div>
            </div>

            <DialogFooter className="mt-4 gap-2 flex-col sm:flex-row">
              <Button variant="ghost" onClick={() => setSelectedUser(null)}>Close folder</Button>
              {selectedUser.kycStatus === "pending" && (
                <>
                  <Button 
                    variant="destructive"
                    onClick={() => kycMutation.mutate({ email: selectedUser.email, status: "rejected" })}
                    disabled={kycMutation.isPending}
                  >
                    <X className="mr-2 h-4 w-4" /> Reject submission
                  </Button>
                  <Button 
                    className="bg-success hover:bg-success/90 text-success-foreground shadow-glow"
                    onClick={() => kycMutation.mutate({ email: selectedUser.email, status: "approved" })}
                    disabled={kycMutation.isPending}
                  >
                    <Check className="mr-2 h-4 w-4" /> Verify Customer
                  </Button>
                </>
              )}
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>
    </div>
  );
}
