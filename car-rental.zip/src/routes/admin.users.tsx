import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Search, UserCheck, ShieldAlert, ArrowLeftRight, UserX } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { userService } from "@/lib/api";
import { toast } from "sonner";
import type { User } from "@/lib/types";

export const Route = createFileRoute("/admin/users")({ component: AdminUsers });

function AdminUsers() {
  const queryClient = useQueryClient();
  const { data: users = [], isLoading } = useQuery({ queryKey: ["users"], queryFn: userService.list });
  
  const [q, setQ] = useState("");

  const roleMutation = useMutation({
    mutationFn: ({ id, role }: { id: string; role: "user" | "admin" }) => 
      userService.updateRole(id, role),
    onSuccess: (updated) => {
      toast.success(`Access permissions for ${updated.name} updated to ${updated.role.toUpperCase()}`);
      queryClient.invalidateQueries({ queryKey: ["users"] });
    },
    onError: () => {
      toast.error("Failed to update user permissions.");
    }
  });

  const banMutation = useMutation({
    mutationFn: async ({ email }: { email: string }) => {
      // Simulate account suspension by updating kycStatus to not_started or rejected
      return userService.updateKyc(email, "rejected");
    },
    onSuccess: (updated) => {
      toast.success(`Account suspension toggled for ${updated.name}`);
      queryClient.invalidateQueries({ queryKey: ["users"] });
    },
    onError: () => {
      toast.error("Failed to suspend account.");
    }
  });

  const filtered = users.filter((u) => 
    `${u.name} ${u.email}`.toLowerCase().includes(q.toLowerCase())
  );

  const getKycBadgeColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-success text-success-foreground border-success/20";
      case "pending":
        return "bg-warning text-warning-foreground border-warning/20 animate-pulse";
      case "rejected":
        return "bg-destructive text-destructive-foreground border-destructive/20";
      case "not_started":
      default:
        return "bg-muted text-muted-foreground border-border";
    }
  };

  return (
    <div className="mx-auto max-w-7xl">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">Users</h1>
          <p className="mt-1 text-muted-foreground">Manage accounts, verify customer licenses and update role permissions.</p>
        </div>
        <div className="relative w-full max-w-xs sm:w-auto">
          <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input 
            value={q} 
            onChange={(e) => setQ(e.target.value)} 
            placeholder="Search by name or email..." 
            className="pl-8 h-8 text-xs w-full sm:w-64" 
          />
        </div>
      </div>

      <Card className="mt-8 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Customer</TableHead>
              <TableHead>User ID</TableHead>
              <TableHead>Contact phone</TableHead>
              <TableHead>KYC Status</TableHead>
              <TableHead>Role</TableHead>
              <TableHead className="text-right">Action Dispatches</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell colSpan={6}>
                    <div className="h-10 animate-pulse rounded bg-muted" />
                  </TableCell>
                </TableRow>
              ))
            ) : filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                  No matching user accounts registered.
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((u) => (
                <TableRow key={u.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback className="bg-primary text-primary-foreground text-xs font-semibold">
                          {u.name.split(" ").map((n) => n[0]).join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-semibold text-sm">{u.name}</p>
                        <p className="text-xs text-muted-foreground">{u.email}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">#{u.id.toUpperCase()}</TableCell>
                  <TableCell className="text-sm font-mono">{u.phone || "—"}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={`capitalize rounded-full text-[10px] ${getKycBadgeColor(u.kycStatus)}`}>
                      {u.kycStatus.replace("_", " ")}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant={u.role === "admin" ? "default" : "secondary"} className="capitalize rounded">
                      {u.role}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1.5">
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="h-8 text-xs cursor-pointer shadow-soft"
                        onClick={() => roleMutation.mutate({ id: u.id, role: u.role === "admin" ? "user" : "admin" })}
                        disabled={roleMutation.isPending}
                        title="Toggle customer role"
                      >
                        <ArrowLeftRight className="h-3.5 w-3.5 mr-1" /> Toggle Role
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="hover:bg-destructive/10 text-destructive border-destructive/20 h-8 cursor-pointer"
                        onClick={() => banMutation.mutate({ email: u.email })}
                        disabled={banMutation.isPending}
                        title="Ban / Suspend credentials"
                      >
                        <UserX className="h-3.5 w-3.5 mr-1" /> Suspend
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
