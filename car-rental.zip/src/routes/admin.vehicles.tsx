import { createFileRoute } from "@tanstack/react-router";
import { Plus, Search, Trash2, Edit, Sliders } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { vehicleService } from "@/lib/api";
import { toast } from "sonner";
import type { Vehicle, VehicleType, FuelType, Transmission } from "@/lib/types";
import { VEHICLE_TYPES, FUEL_TYPES, TRANSMISSIONS } from "@/constants";

export const Route = createFileRoute("/admin/vehicles")({ component: AdminVehicles });

type VehicleFormVals = {
  name: string;
  brand: string;
  model: string;
  year: number;
  type: VehicleType;
  fuel: FuelType;
  transmission: Transmission;
  seats: number;
  pricePerDay: number;
  location: string;
  image: string;
  description: string;
  mileage: string;
  engine: string;
  topSpeed: string;
  acceleration: string;
};

function AdminVehicles() {
  const queryClient = useQueryClient();
  const { data: vehicles = [], isLoading } = useQuery({ queryKey: ["vehicles"], queryFn: vehicleService.list });
  
  const [q, setQ] = useState("");
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);

  const filtered = vehicles.filter((v) => 
    `${v.name} ${v.brand} ${v.type}`.toLowerCase().includes(q.toLowerCase())
  );

  const { register: regAdd, handleSubmit: handleAddSubmit, reset: resetAdd, setValue: setAddVal } = useForm<VehicleFormVals>({
    defaultValues: { type: "sedan", fuel: "petrol", transmission: "automatic", seats: 5, pricePerDay: 80, year: 2024 }
  });

  const { register: regEdit, handleSubmit: handleEditSubmit, reset: resetEdit, setValue: setEditVal } = useForm<VehicleFormVals>();

  const createMutation = useMutation({
    mutationFn: (data: VehicleFormVals) => {
      const formatted = {
        name: data.name,
        brand: data.brand,
        model: data.model,
        year: Number(data.year),
        type: data.type,
        fuel: data.fuel,
        transmission: data.transmission,
        seats: Number(data.seats),
        pricePerDay: Number(data.pricePerDay),
        location: data.location,
        image: data.image || "https://images.unsplash.com/photo-1617788138017-80ad40651399?w=1200&q=80&auto=format&fit=crop",
        description: data.description,
        features: ["Premium Audio", "Heated Seats", "Apple CarPlay"],
        specs: {
          mileage: data.mileage || "25 mpg",
          engine: data.engine || "2.0L Turbo",
          topSpeed: data.topSpeed || "140 mph",
          acceleration: data.acceleration || "6.5s 0-60",
        },
        images: [data.image || "https://images.unsplash.com/photo-1617788138017-80ad40651399?w=1200&q=80&auto=format&fit=crop"],
      };
      return vehicleService.create(formatted);
    },
    onSuccess: (newVehicle) => {
      toast.success(`${newVehicle.name} successfully added to the fleet!`);
      queryClient.invalidateQueries({ queryKey: ["vehicles"] });
      setIsAddOpen(false);
      resetAdd();
    },
    onError: () => {
      toast.error("Failed to add vehicle. Check details and try again.");
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, patch }: { id: string; patch: Partial<Vehicle> }) => 
      vehicleService.update(id, patch),
    onSuccess: (updated) => {
      toast.success(`${updated.name} successfully updated!`);
      queryClient.invalidateQueries({ queryKey: ["vehicles"] });
      setEditingVehicle(null);
    },
    onError: () => {
      toast.error("Failed to update vehicle.");
    }
  });

  const onAddSubmit = (data: VehicleFormVals) => {
    createMutation.mutate(data);
  };

  const startEdit = (v: Vehicle) => {
    setEditingVehicle(v);
    setEditVal("name", v.name);
    setEditVal("brand", v.brand);
    setEditVal("model", v.model);
    setEditVal("year", v.year);
    setEditVal("type", v.type);
    setEditVal("fuel", v.fuel);
    setEditVal("transmission", v.transmission);
    setEditVal("seats", v.seats);
    setEditVal("pricePerDay", v.pricePerDay);
    setEditVal("location", v.location);
    setEditVal("image", v.image);
    setEditVal("description", v.description);
    setEditVal("mileage", v.specs.mileage);
    setEditVal("engine", v.specs.engine);
    setEditVal("topSpeed", v.specs.topSpeed);
    setEditVal("acceleration", v.specs.acceleration);
  };

  const onEditSubmit = (data: VehicleFormVals) => {
    if (!editingVehicle) return;
    const patch: Partial<Vehicle> = {
      name: data.name,
      brand: data.brand,
      model: data.model,
      year: Number(data.year),
      type: data.type,
      fuel: data.fuel,
      transmission: data.transmission,
      seats: Number(data.seats),
      pricePerDay: Number(data.pricePerDay),
      location: data.location,
      image: data.image,
      description: data.description,
      specs: {
        mileage: data.mileage,
        engine: data.engine,
        topSpeed: data.topSpeed,
        acceleration: data.acceleration,
      }
    };
    updateMutation.mutate({ id: editingVehicle.id, patch });
  };

  const toggleAvailability = (v: Vehicle) => {
    updateMutation.mutate({ id: v.id, patch: { available: !v.available } });
  };

  return (
    <div className="mx-auto max-w-7xl">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold tracking-tight">Vehicle Management</h1>
          <p className="mt-1 text-muted-foreground">{vehicles.length} vehicles registered in your fleet</p>
        </div>
        <Button className="shadow-soft cursor-pointer" onClick={() => setIsAddOpen(true)}>
          <Plus className="mr-2 h-4 w-4" /> Add Vehicle
        </Button>
      </div>

      <Card className="mt-8 overflow-hidden">
        <div className="border-b border-border p-4">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search fleet by brand, name or class…" className="pl-9" />
          </div>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Vehicle</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Price/Day</TableHead>
              <TableHead>Specs</TableHead>
              <TableHead>Location</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i}><TableCell colSpan={7}><div className="h-10 animate-pulse rounded bg-muted" /></TableCell></TableRow>
              ))
            ) : filtered.length === 0 ? (
              <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No matching fleet vehicles found.</TableCell></TableRow>
            ) : filtered.map((v) => (
              <TableRow key={v.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <img src={v.image} alt="" className="h-12 w-16 rounded-md object-cover border border-border" />
                    <div>
                      <p className="font-semibold text-sm leading-none mb-1">{v.name}</p>
                      <p className="text-xs text-muted-foreground">{v.brand} • {v.year}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell><Badge variant="secondary" className="capitalize">{v.type}</Badge></TableCell>
                <TableCell className="font-semibold text-sm">${v.pricePerDay}</TableCell>
                <TableCell>
                  <div className="text-xs space-y-0.5 text-muted-foreground">
                    <p>{v.seats} seats • {v.fuel}</p>
                    <p className="font-mono text-[10px]">{v.transmission}</p>
                  </div>
                </TableCell>
                <TableCell className="text-xs text-muted-foreground">{v.location}</TableCell>
                <TableCell>
                  <button 
                    onClick={() => toggleAvailability(v)}
                    className="cursor-pointer"
                    title="Click to toggle availability status"
                  >
                    <Badge variant={v.available ? "default" : "secondary"} className={v.available ? "bg-success text-success-foreground hover:bg-success/90 shadow-soft" : "hover:bg-muted"}>
                      {v.available ? "Available" : "In use / Blocked"}
                    </Badge>
                  </button>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1.5">
                    <Button size="sm" variant="ghost" className="h-8 w-8 p-0 cursor-pointer" onClick={() => startEdit(v)}>
                      <Edit className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      {/* Add Vehicle Modal Dialog */}
      <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto sm:rounded-2xl">
          <DialogHeader>
            <DialogTitle className="font-display text-xl font-bold">Add new luxury vehicle</DialogTitle>
            <DialogDescription>Add a premium car to DriveLux's rentable inventory.</DialogDescription>
          </DialogHeader>

          <form onSubmit={handleAddSubmit(onAddSubmit)} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-3">
              <div>
                <Label>Brand</Label>
                <Input placeholder="Tesla" {...regAdd("brand", { required: true })} />
              </div>
              <div>
                <Label>Model</Label>
                <Input placeholder="Model X" {...regAdd("model", { required: true })} />
              </div>
              <div>
                <Label>Vehicle Display Name</Label>
                <Input placeholder="Tesla Model X Plaid" {...regAdd("name", { required: true })} />
              </div>
              <div>
                <Label>Year</Label>
                <Input type="number" {...regAdd("year", { required: true })} />
              </div>
              <div>
                <Label>Seats</Label>
                <Input type="number" {...regAdd("seats", { required: true })} />
              </div>
              <div>
                <Label>Price per Day ($)</Label>
                <Input type="number" {...regAdd("pricePerDay", { required: true })} />
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-3">
              <div>
                <Label>Category</Label>
                <Select defaultValue="sedan" onValueChange={(val) => setAddVal("type", val as VehicleType)}>
                  <SelectTrigger className="w-full mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {VEHICLE_TYPES.map((t) => <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Fuel System</Label>
                <Select defaultValue="electric" onValueChange={(val) => setAddVal("fuel", val as FuelType)}>
                  <SelectTrigger className="w-full mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {FUEL_TYPES.map((f) => <SelectItem key={f} value={f} className="capitalize">{f}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Transmission</Label>
                <Select defaultValue="automatic" onValueChange={(val) => setAddVal("transmission", val as Transmission)}>
                  <SelectTrigger className="w-full mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TRANSMISSIONS.map((t) => <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label>Ocular Location</Label>
                <Input placeholder="Los Angeles, CA" {...regAdd("location", { required: true })} />
              </div>
              <div>
                <Label>Image URL (Unsplash/Premium)</Label>
                <Input placeholder="https://images.unsplash.com/..." {...regAdd("image")} />
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-4">
              <div><Label>Mileage / Range</Label><Input placeholder="400 mi range" {...regAdd("mileage")} /></div>
              <div><Label>Engine / Power</Label><Input placeholder="Dual-Motor EV" {...regAdd("engine")} /></div>
              <div><Label>Top Speed</Label><Input placeholder="155 mph" {...regAdd("topSpeed")} /></div>
              <div><Label>Acceleration</Label><Input placeholder="2.5s 0-60" {...regAdd("acceleration")} /></div>
            </div>

            <div>
              <Label>Description</Label>
              <textarea 
                className="w-full border border-input bg-background rounded-lg p-2.5 text-sm h-20 focus:ring-1 focus:ring-primary outline-none mt-1" 
                placeholder="Write a high-fidelity SaaS description showcasing track-bred performance or everyday grand touring features..."
                {...regAdd("description", { required: true })}
              />
            </div>

            <DialogFooter className="mt-6">
              <Button type="button" variant="ghost" onClick={() => setIsAddOpen(false)}>Cancel</Button>
              <Button type="submit" className="shadow-glow" disabled={createMutation.isPending}>
                {createMutation.isPending ? "Creating..." : "Commission Vehicle"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Vehicle Modal Dialog */}
      <Dialog open={editingVehicle !== null} onOpenChange={(open) => !open && setEditingVehicle(null)}>
        {editingVehicle && (
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto sm:rounded-2xl">
            <DialogHeader>
              <DialogTitle className="font-display text-xl font-bold">Edit vehicle specifications</DialogTitle>
              <DialogDescription>Adjust fleet values for #{editingVehicle.id.toUpperCase()} ({editingVehicle.name})</DialogDescription>
            </DialogHeader>

            <form onSubmit={handleEditSubmit(onEditSubmit)} className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-3">
                <div>
                  <Label>Brand</Label>
                  <Input {...regEdit("brand", { required: true })} />
                </div>
                <div>
                  <Label>Model</Label>
                  <Input {...regEdit("model", { required: true })} />
                </div>
                <div>
                  <Label>Vehicle Display Name</Label>
                  <Input {...regEdit("name", { required: true })} />
                </div>
                <div>
                  <Label>Year</Label>
                  <Input type="number" {...regEdit("year", { required: true })} />
                </div>
                <div>
                  <Label>Seats</Label>
                  <Input type="number" {...regEdit("seats", { required: true })} />
                </div>
                <div>
                  <Label>Price per Day ($)</Label>
                  <Input type="number" {...regEdit("pricePerDay", { required: true })} />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-3">
                <div>
                  <Label>Category</Label>
                  <Select defaultValue={editingVehicle.type} onValueChange={(val) => setEditVal("type", val as VehicleType)}>
                    <SelectTrigger className="w-full mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {VEHICLE_TYPES.map((t) => <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Fuel System</Label>
                  <Select defaultValue={editingVehicle.fuel} onValueChange={(val) => setEditVal("fuel", val as FuelType)}>
                    <SelectTrigger className="w-full mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {FUEL_TYPES.map((f) => <SelectItem key={f} value={f} className="capitalize">{f}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Transmission</Label>
                  <Select defaultValue={editingVehicle.transmission} onValueChange={(val) => setEditVal("transmission", val as Transmission)}>
                    <SelectTrigger className="w-full mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {TRANSMISSIONS.map((t) => <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label>Ocular Location</Label>
                  <Input {...regEdit("location", { required: true })} />
                </div>
                <div>
                  <Label>Image URL</Label>
                  <Input {...regEdit("image")} />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-4">
                <div><Label>Mileage / Range</Label><Input {...regEdit("mileage")} /></div>
                <div><Label>Engine / Power</Label><Input {...regEdit("engine")} /></div>
                <div><Label>Top Speed</Label><Input {...regEdit("topSpeed")} /></div>
                <div><Label>Acceleration</Label><Input {...regEdit("acceleration")} /></div>
              </div>

              <div>
                <Label>Description</Label>
                <textarea 
                  className="w-full border border-input bg-background rounded-lg p-2.5 text-sm h-20 focus:ring-1 focus:ring-primary outline-none mt-1" 
                  {...regEdit("description", { required: true })}
                />
              </div>

              <DialogFooter className="mt-6">
                <Button type="button" variant="ghost" onClick={() => setEditingVehicle(null)}>Cancel</Button>
                <Button type="submit" disabled={updateMutation.isPending}>
                  {updateMutation.isPending ? "Saving..." : "Save changes"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        )}
      </Dialog>
    </div>
  );
}
