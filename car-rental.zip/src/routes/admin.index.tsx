import { createFileRoute } from "@tanstack/react-router";
import { Activity, CalendarRange, Car, DollarSign, Users } from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  BarChart,
  Bar,
  Legend,
} from "recharts";
import { StatCard } from "@/components/dashboard/StatCard";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/admin/")({ component: AdminHome });

const revenueData = [
  { month: "Jan", revenue: 42000, bookings: 120 },
  { month: "Feb", revenue: 48000, bookings: 142 },
  { month: "Mar", revenue: 55000, bookings: 168 },
  { month: "Apr", revenue: 62000, bookings: 190 },
  { month: "May", revenue: 71000, bookings: 215 },
  { month: "Jun", revenue: 84000, bookings: 248 },
];

const fleetData = [
  { type: "Sedan", count: 124 },
  { type: "SUV", count: 98 },
  { type: "Luxury", count: 56 },
  { type: "EV", count: 78 },
  { type: "Convert.", count: 32 },
];

// Chart palette: resolved from CSS custom properties at runtime so dark mode works.
function useCssVar(name: string) {
  if (typeof window === "undefined") return "";
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

function ChartColors() {
  return null;
}

function AdminHome() {
  // Read actual oklch values so recharts renders correctly in both modes.
  const border = typeof window !== "undefined"
    ? getComputedStyle(document.documentElement).getPropertyValue("--border").trim()
    : "oklch(0.92 0.008 250)";
  const muted = typeof window !== "undefined"
    ? getComputedStyle(document.documentElement).getPropertyValue("--muted-foreground").trim()
    : "oklch(0.50 0.02 250)";
  const cardBg = typeof window !== "undefined"
    ? getComputedStyle(document.documentElement).getPropertyValue("--card").trim()
    : "white";

  // Use fixed theme-aware Tailwind class colors directly as hex for recharts compatibility.
  const primaryColor = "#6366f1";
  const chart2Color = "#10b981";
  const tooltipStyle = {
    background: "var(--color-card)",
    border: "1px solid var(--color-border)",
    borderRadius: 12,
    color: "var(--color-card-foreground)",
    fontSize: 13,
  };
  const gridColor = "var(--color-border)";
  const axisColor = "var(--color-muted-foreground)";

  return (
    <div className="mx-auto max-w-7xl">
      <div>
        <h1 className="font-display text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="mt-1 text-muted-foreground">Overview of your fleet operations and revenue.</p>
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Total Revenue" value="$362K" delta="+18.2%" icon={DollarSign} />
        <StatCard label="Active Bookings" value="248" delta="+12%" icon={CalendarRange} />
        <StatCard label="Fleet Size" value="388" delta="+8 added" icon={Car} />
        <StatCard label="Customers" value="12,480" delta="+342" icon={Users} />
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        <Card className="p-6 lg:col-span-2">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-display text-lg font-semibold">Revenue trend</h3>
              <p className="text-sm text-muted-foreground">Last 6 months</p>
            </div>
            <Badge variant="secondary" className="gap-1"><Activity className="h-3 w-3" /> Live</Badge>
          </div>
          <div className="mt-6 h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={primaryColor} stopOpacity={0.3} />
                    <stop offset="100%" stopColor={primaryColor} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
                <XAxis dataKey="month" stroke={axisColor} fontSize={12} />
                <YAxis stroke={axisColor} fontSize={12} />
                <Tooltip contentStyle={tooltipStyle} />
                <Area type="monotone" dataKey="revenue" stroke={primaryColor} strokeWidth={2.5} fill="url(#rev)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="font-display text-lg font-semibold">Fleet composition</h3>
          <p className="text-sm text-muted-foreground">By category</p>
          <div className="mt-6 h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={fleetData}>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
                <XAxis dataKey="type" stroke={axisColor} fontSize={11} />
                <YAxis stroke={axisColor} fontSize={11} />
                <Tooltip contentStyle={tooltipStyle} />
                <Bar dataKey="count" fill={primaryColor} radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <Card className="p-6">
          <h3 className="font-display text-lg font-semibold">Bookings volume</h3>
          <p className="text-sm text-muted-foreground">Monthly</p>
          <div className="mt-6 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
                <XAxis dataKey="month" stroke={axisColor} fontSize={11} />
                <YAxis stroke={axisColor} fontSize={11} />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend />
                <Bar dataKey="bookings" fill={chart2Color} radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="font-display text-lg font-semibold">Recent activity</h3>
          <div className="mt-4 divide-y divide-border">
            {[
              ["New booking", "Tesla Model S — Sarah K.", "2m ago"],
              ["KYC approved", "Marcus J. verified", "12m ago"],
              ["Vehicle returned", "BMW M4 — undamaged", "1h ago"],
              ["Maintenance complete", "Range Rover #RR-12", "3h ago"],
              ["Payment received", "$1,240 — Elena R.", "4h ago"],
            ].map(([t, d, time], i) => (
              <div key={i} className="flex items-center justify-between py-3">
                <div>
                  <p className="text-sm font-medium">{t}</p>
                  <p className="text-xs text-muted-foreground">{d}</p>
                </div>
                <span className="text-xs text-muted-foreground">{time}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
