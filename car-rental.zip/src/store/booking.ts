import { create } from "zustand";

interface BookingDraft {
  vehicleId?: string;
  startDate?: string;
  endDate?: string;
  pickupLocation?: string;
  dropoffLocation?: string;
  addons: string[];
}

interface BookingState {
  draft: BookingDraft;
  setDraft: (patch: Partial<BookingDraft>) => void;
  reset: () => void;
}

export const useBookingDraft = create<BookingState>((set) => ({
  draft: { addons: [] },
  setDraft: (patch) => set((s) => ({ draft: { ...s.draft, ...patch } })),
  reset: () => set({ draft: { addons: [] } }),
}));
