// Axios-based API service layer. Replace baseURL with real backend.
import axios from "axios";
import { vehicles as baseVehicles, bookings as baseBookings, reviews as baseReviews } from "./mock-data";
import type { Vehicle, Booking, Review, User, KycStatus, BookingStatus } from "./types";

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL ?? "/api",
  timeout: 15000,
});

api.interceptors.request.use((config) => {
  const token = typeof window !== "undefined" ? localStorage.getItem("auth_token") : null;
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

const delay = (ms = 400) => new Promise((r) => setTimeout(r, ms));

// --- PERSISTENT MOCK DATABASE ---
const getStorageItem = <T>(key: string, defaultValue: T): T => {
  if (typeof window === "undefined") return defaultValue;
  const raw = localStorage.getItem(key);
  if (!raw) {
    localStorage.setItem(key, JSON.stringify(defaultValue));
    return defaultValue;
  }
  return JSON.parse(raw);
};

const setStorageItem = <T>(key: string, value: T) => {
  if (typeof window !== "undefined") {
    localStorage.setItem(key, JSON.stringify(value));
  }
};

// Initial state persistence
const getVehicles = (): Vehicle[] => getStorageItem("drivelux-db-vehicles", baseVehicles);
const setVehicles = (list: Vehicle[]) => setStorageItem("drivelux-db-vehicles", list);

const getBookings = (): Booking[] => getStorageItem("drivelux-db-bookings", baseBookings);
const setBookings = (list: Booking[]) => setStorageItem("drivelux-db-bookings", list);

// Let's create a base mock user list
const baseUsers: User[] = [
  { id: "u1", name: "Sarah Chen", email: "sarah@example.com", phone: "+1 (555) 123-4567", role: "user", kycStatus: "approved" },
  { id: "u2", name: "Marcus Johnson", email: "marcus@example.com", phone: "+1 (555) 765-4321", role: "user", kycStatus: "approved" },
  { id: "u3", name: "Elena Rossi", email: "elena@example.com", phone: "+39 333 456 7890", role: "user", kycStatus: "pending" },
  { id: "u4", name: "David Kim", email: "david@example.com", phone: "+1 (555) 987-6543", role: "user", kycStatus: "approved" },
  { id: "u5", name: "Maya Patel", email: "maya@example.com", phone: "+1 (555) 555-0199", role: "user", kycStatus: "not_started" },
  { id: "admin1", name: "DriveLux Admin", email: "admin@drivelux.com", phone: "+1 (555) 999-9999", role: "admin", kycStatus: "approved" },
];
const getUsers = (): User[] => getStorageItem("drivelux-db-users", baseUsers);
const setUsers = (list: User[]) => setStorageItem("drivelux-db-users", list);

// --- END MOCK DATABASE ---

export const vehicleService = {
  list: async (): Promise<Vehicle[]> => { await delay(); return getVehicles(); },
  get: async (id: string): Promise<Vehicle | undefined> => { await delay(); return getVehicles().find((v) => v.id === id); },
  reviews: async (_id: string): Promise<Review[]> => { await delay(); return baseReviews; },
  
  // Admin / CRUD functions
  create: async (vehicle: Omit<Vehicle, "id" | "rating" | "reviewCount" | "available">): Promise<Vehicle> => {
    await delay();
    const list = getVehicles();
    const newVehicle: Vehicle = {
      ...vehicle,
      id: `v${list.length + 1}`,
      rating: 5.0,
      reviewCount: 0,
      available: true,
      images: vehicle.images && vehicle.images.length > 0 ? vehicle.images : [vehicle.image],
    };
    list.push(newVehicle);
    setVehicles(list);
    return newVehicle;
  },
  update: async (id: string, patch: Partial<Vehicle>): Promise<Vehicle> => {
    await delay();
    const list = getVehicles();
    const idx = list.findIndex((v) => v.id === id);
    if (idx === -1) throw new Error("Vehicle not found");
    list[idx] = { ...list[idx], ...patch };
    setVehicles(list);
    return list[idx];
  }
};

export const bookingService = {
  list: async (): Promise<Booking[]> => { await delay(); return getBookings(); },
  get: async (id: string): Promise<Booking | undefined> => { await delay(); return getBookings().find((b) => b.id === id); },
  create: async (booking: Omit<Booking, "id" | "createdAt" | "status">): Promise<Booking> => {
    await delay();
    const list = getBookings();
    const newBooking: Booking = { 
      ...booking, 
      id: `BK-${Math.floor(10000 + Math.random() * 90000)}`, 
      createdAt: new Date().toISOString().split("T")[0], 
      status: "confirmed" 
    };
    list.unshift(newBooking);
    setBookings(list);
    return newBooking;
  },
  updateStatus: async (id: string, status: BookingStatus): Promise<Booking> => {
    await delay();
    const list = getBookings();
    const idx = list.findIndex((b) => b.id === id);
    if (idx === -1) throw new Error("Booking not found");
    list[idx].status = status;
    setBookings(list);
    return list[idx];
  }
};

export const userService = {
  list: async (): Promise<User[]> => { await delay(); return getUsers(); },
  updateKyc: async (email: string, kycStatus: KycStatus): Promise<User> => {
    await delay();
    const list = getUsers();
    const idx = list.findIndex((u) => u.email === email);
    if (idx === -1) throw new Error("User not found");
    list[idx].kycStatus = kycStatus;
    setUsers(list);
    
    // Update auth user if it matches
    if (typeof window !== "undefined") {
      const raw = localStorage.getItem("drivelux-auth");
      if (raw) {
        const state = JSON.parse(raw);
        if (state.state?.user?.email === email) {
          state.state.user.kycStatus = kycStatus;
          localStorage.setItem("drivelux-auth", JSON.stringify(state));
        }
      }
    }
    
    return list[idx];
  },
  updateRole: async (id: string, role: "user" | "admin"): Promise<User> => {
    await delay();
    const list = getUsers();
    const idx = list.findIndex((u) => u.id === id);
    if (idx === -1) throw new Error("User not found");
    list[idx].role = role;
    setUsers(list);
    return list[idx];
  }
};
