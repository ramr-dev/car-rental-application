export type VehicleType = "sedan" | "suv" | "luxury" | "electric" | "convertible" | "van";
export type FuelType = "petrol" | "diesel" | "electric" | "hybrid";
export type Transmission = "automatic" | "manual";
export type BookingStatus = "pending" | "confirmed" | "active" | "completed" | "cancelled";
export type KycStatus = "not_started" | "pending" | "approved" | "rejected";

export interface Vehicle {
  id: string;
  name: string;
  brand: string;
  model: string;
  year: number;
  type: VehicleType;
  fuel: FuelType;
  transmission: Transmission;
  seats: number;
  pricePerDay: number;
  rating: number;
  reviewCount: number;
  location: string;
  image: string;
  images: string[];
  features: string[];
  available: boolean;
  description: string;
  specs: {
    mileage: string;
    engine: string;
    topSpeed: string;
    acceleration: string;
  };
}

export interface Review {
  id: string;
  user: string;
  avatar: string;
  rating: number;
  date: string;
  comment: string;
}

export interface Booking {
  id: string;
  vehicleId: string;
  vehicleName: string;
  vehicleImage: string;
  startDate: string;
  endDate: string;
  pickupLocation: string;
  dropoffLocation: string;
  totalPrice: number;
  status: BookingStatus;
  createdAt: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatar?: string;
  role: "user" | "admin";
  kycStatus: KycStatus;
}
